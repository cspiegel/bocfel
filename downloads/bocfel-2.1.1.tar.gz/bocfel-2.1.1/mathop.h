// vim: set ft=cpp:

#ifndef ZTERP_MATH_H
#define ZTERP_MATH_H

void zinc();
void zdec();
void znot();
void zdec_chk();
void zinc_chk();
void ztest();
void zor();
void zand();
void zadd();
void zsub();
void zmul();
void zdiv();
void zmod();
void zlog_shift();
void zart_shift();

#endif
