ifeq ($(CXX), g++)
COMPILER_FLAGS=	-MMD -MP -MF .deps/$(*F).d -Wall -Wshadow -Wswitch -Wno-sign-compare -std=c++17 -pedantic
endif

ifeq ($(CXX), clang++)
COMPILER_FLAGS=	-MMD -MP -MF .deps/$(*F).d -Wall -Wunused-macros -std=c++17 -pedantic
endif

ifeq ($(CXX), icpc)
COMPILER_FLAGS=	-Wall -std=c++17
endif

ifeq ($(CXX), icpx)
COMPILER_FLAGS=	-MMD -MP -MF .deps/$(*F).d -Wall -std=c++17
endif

ifeq ($(CXXHOST),)
REALCXX:=	$(CXX)
else
REALCXX:=	$(CXXHOST)-$(CXX)
endif
