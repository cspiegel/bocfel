#ifndef DICTIONARY_H
#define DICTIONARY_H

#include <stdint.h>

void tokenize(uint16_t, uint16_t, uint16_t, int);

void ztokenise(void);
void zencode_text(void);

#endif
