// vim: set ft=c:

#ifndef ZTERP_SOUND_H
#define ZTERP_SOUND_H

#include <stdbool.h>

void init_sound(void);
bool sound_loaded(void);

void zsound_effect(void);

#endif
