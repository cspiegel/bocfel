#ifndef ZTERP_META_H
#define ZTERP_META_H

const uint32_t *handle_meta_command(const uint32_t *);

extern uint32_t read_pc;

#endif
