#ifndef ZTERP_BRANCH_H
#define ZTERP_BRANCH_H

void branch_if(int);

void zjump(void);
void zjz(void);
void zje(void);
void zjl(void);
void zjg(void);

#endif
