#ifndef ZTERP_ZOOM_H
#define ZTERP_ZOOM_H

void zstart_timer(void);
void zstop_timer(void);
void zread_timer(void);
void zprint_timer(void);

#endif
