#ifndef ZTERP_PATCHES_H
#define ZTERP_PATCHES_H

void apply_patches(void);

#endif
