#ifndef ZTERP_SOUND_H
#define ZTERP_SOUND_H

void init_sound(int);
int sound_loaded(void);

void zsound_effect(void);

#endif
