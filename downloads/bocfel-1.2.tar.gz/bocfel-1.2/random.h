// vim: set ft=c:

#ifndef ZTERP_MT_H
#define ZTERP_MT_H

void seed_random(long);

void zrandom(void);

#endif
