#ifndef ZTERP_MT_H
#define ZTERP_MT_H

#include <stdint.h>

void seed_random(int);

void zrandom(void);

#endif
