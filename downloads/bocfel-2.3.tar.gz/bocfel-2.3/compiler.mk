ifeq ($(CXX), g++)
COMPILER_FLAGS=	-MMD -MP -Wall -Wshadow -Wswitch -Wno-sign-compare -std=c++14 -pedantic
endif

ifeq ($(CXX), clang++)
COMPILER_FLAGS=	-MMD -MP -Wall -Wunused-macros -std=c++14 -pedantic
endif

ifeq ($(CXX), icpc)
COMPILER_FLAGS=	-Wall -std=c++14
endif

ifeq ($(CXX), icpx)
COMPILER_FLAGS=	-MMD -MP -Wall -std=c++14
endif

ifeq ($(CXX), sunCC)
COMPILER_FLAGS=	-xMMD -std=c++14 -pedantic
endif

ifeq ($(CXXHOST),)
REALCXX:=	$(CXX)
else
REALCXX:=	$(CXXHOST)-$(CXX)
endif
