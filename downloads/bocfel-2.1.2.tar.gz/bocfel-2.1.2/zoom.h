// vim: set ft=cpp:

#ifndef ZTERP_ZOOM_H
#define ZTERP_ZOOM_H

void zstart_timer();
void zstop_timer();
void zread_timer();
void zprint_timer();

#endif
