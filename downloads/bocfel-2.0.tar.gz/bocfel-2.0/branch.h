// vim: set ft=cpp:

#ifndef ZTERP_BRANCH_H
#define ZTERP_BRANCH_H

void branch_if(bool do_branch);

void zjump();
void zjz();
void zje();
void zjl();
void zjg();

#endif
