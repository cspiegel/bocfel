#ifndef ZTERP_TABLE_H
#define ZTERP_TABLE_H

void zcopy_table(void);
void zscan_table(void);
void zloadw(void);
void zloadb(void);
void zstoreb(void);
void zstorew(void);

#endif
